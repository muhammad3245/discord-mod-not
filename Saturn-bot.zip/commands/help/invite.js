const discord = require("discord.js");

module.exports = {
  name: "invite",
  category: "info",
  description: "INVITE Saturn BOT",
  run: async (client, message, args) => {
    
    let embed = new discord.MessageEmbed()
    .setTitle(`Sorry!`)
    .setDescription(`• This bot is only for Oceanics Server and cannot be invited`)
    .setColor("RANDOM")
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter(
      `Oceanics Bot`,
      client.user.displayAvatarURL(),
      message.delete()
    );
    
    message.channel .send(embed)
    
  
  }
}