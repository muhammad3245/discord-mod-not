const mongoose = require("mongoose");
const config = require("./config");

mongoose.connect("mongodb+srv://MuhammadHussnain:June7thhot@cluster0.9z9gw.mongodb.net/myFirstDatabase?retryWrites=true&w=majority", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
mongoose.connection.on("connected", () => {
  console.log("[✅ DataBase] Connected!");
});
module.exports = mongoose;
